# Protocol run summary — sint-memory-mcp

Not a ranking. This is a per-operation profile of one memory server under the
protocol in `protocol.md`; another server's profile is a separate report and the
two are meant to be read side by side, not scored against each other.

| field | value |
|---|---|
| subject | sint-memory-mcp |
| repository / commit | https://github.com/kostyk348/sint @ 7554f7eef853cebafae34e6654acc9871fb01163 |
| transport / MCP revision | stdio / 2025-03-26 |
| runtime | Python 3.14.7, mcp 1.9.4 (mcp.server.fastmcp) |
| model under test | none (store-only) |
| seeds / repetitions | [1, 2, 3] / 3 |
| max_calls per repetition | 400 |
| environment | windows; Intel64 Family 6 Model 140 Stepping 2, GenuineIntel; server interpreter <hermes-venv>/Scripts/python.exe; harness protorun (Rust, standard library only, no crates) |
| raw responses | reports/parity-rust/sint-memory-mcp-2026-10-16/raw |

## Metrics by task family

### T1 (12 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| write_precision | 0.7500 | [0.7500, 0.7500] | 3 | harness | correct_written_records / written_records. A stored record counts as correct when it matches a generated fact and is not an extra copy of one; written_records i |
| write_recall | 1.0000 | [1.0000, 1.0000] | 3 | harness | correct_written_records / generated_facts; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| duplicate_rate | 0.2500 | [0.2500, 0.2500] | 3 | harness | extra_records_from_retries / written_records; a retry is the same content with the same intent; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resam |
| idempotency_violations | 4.0000 | [4.0000, 4.0000] | 3 | programmatic_check | retries that created an extra record (protocol.md section 3); mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| write_latency_p50_ms | 18.6060 | [18.0490, 19.0040] | 3 | harness | wall clock around tools/call; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| write_latency_p95_ms | 22.8851 | [21.3448, 24.4217] | 3 | harness | mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| tokens_per_write | null | — | 0 | harness | null: no model is in the loop, so no token accounting exists; payload sizes are in the raw log; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resam |
| cost_per_1000_writes_usd | null | — | 0 | harness | null: store-only run, no per-token price applies (see budgets.price_table); mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repet |

### T2 (6 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| recall_at_5 | 1.0000 | [1.0000, 1.0000] | 3 | harness | required record inside the top k returned; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| required_record_hit_rate | 1.0000 | [1.0000, 1.0000] | 3 | harness | required record anywhere in the returned list, ignoring k; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| mrr | 0.7500 | [0.6806, 0.8056] | 3 | harness | mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| key_query_hit_rate | 1.0000 | [1.0000, 1.0000] | 3 | harness | queries that repeat the record's content verbatim; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| topic_query_hit_rate | 1.0000 | [1.0000, 1.0000] | 3 | harness | queries that name only a shared topic token, so several records match; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition |
| provenance_correctness | 1.0000 | [1.0000, 1.0000] | 3 | harness | returned records whose source field matches the generated record; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| context_inflation | 2.5000 | [2.5000, 2.5000] | 3 | harness | characters returned / characters of the records actually required (character ratio, not tokens: no tokenizer in the loop); mean over 3 repetitions, percentile b |
| read_latency_p50_ms | 8.9428 | [8.5450, 9.4735] | 3 | harness | mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| read_latency_p95_ms | 139.7200 | [109.9360, 194.4255] | 3 | harness | mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |

### T3 (4 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| temporal_correctness | null | — | 0 | harness | null / not_implemented: the server exposes no date-scoped read, so the as-of probe cannot be answered; mean over 3 repetitions, percentile bootstrap 95% CI (100 |
| temporal_metadata_exposed | 1.0000 | [1.0000, 1.0000] | 3 | programmatic_check | fraction of read-back records carrying a timestamp field (metadata exists, the query does not); mean over 3 repetitions, percentile bootstrap 95% CI (1000 resam |

- failure `not_implemented` ×12: probe 'as of 2026-02-01' for t3-1-00: no tool accepts an as-of date

### T4 (6 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| admissibility_error_rate | 0.5000 | [0.5000, 0.5000] | 3 | programmatic_check | returned records that belong to a different principal than the caller; the tool surface has no caller parameter, so this is a policy check over the responses; m |
| lifecycle_state_exposed | 0.0000 | [0.0000, 0.0000] | 3 | programmatic_check | returned records exposing a lifecycle field (expiry/supersede marker); mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition |
| principal_scoping_exposed | 0.0000 | [0.0000, 0.0000] | 3 | programmatic_check | fraction of tools whose input schema accepts a caller/principal argument; read from the tools/list inputSchema of this run; mean over 3 repetitions, percentile  |

### T5 (4 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| contradiction_detection_f1 | 0.0000 | [0.0000, 0.0000] | 3 | harness | F1 of conflicts the store flags by itself after the contradicting writes; the harness never names a conflicting pair, so this measures detection, not registrati |
| revision_correctness | null | — | 0 | programmatic_check | null / not_implemented: append-only store, no operation retires or rewrites a record; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over |
| chain_completeness | 0.0000 | [0.0000, 0.0000] | 3 | programmatic_check | 0.0: the append-only chain has no revision edge to resolve; every write is a new block; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) ov |
| stale_read_rate | 1.0000 | [1.0000, 1.0000] | 3 | harness | post-conflict probes where the superseded content is still served by the read path; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over t |
| both_competing_contents_served_rate | 1.0000 | [1.0000, 1.0000] | 3 | harness | fraction of conflicts where both the kept and the superseded content are returned: the store holds no resolution; mean over 3 repetitions, percentile bootstrap  |
| policy_winner_top_ranked_rate | 0.5000 | [0.5000, 0.5000] | 3 | harness | top-ranked record for the conflict subject matching the stated policy winner; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the rep |
| collateral_change_rate | 0.0000 | [0.0000, 0.0000] | 3 | programmatic_check | fraction of unrelated records whose content hash changed during revision; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetit |

- failure `not_implemented` ×12: the block store is append-only: no operation rewrites or retires a block

### T6 (4 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| probe_survival_rate | 1.0000 | [1.0000, 1.0000] | 3 | harness | identical probes answered identically before and after the maintenance pass; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repe |
| compression_ratio | 1.0000 | [1.0000, 1.0000] | 3 | harness | items_before / items_after the pass; this pass audits records rather than merging them; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) ov |
| derived_from_completeness | null | — | 0 | programmatic_check | null: no generalisations are produced, so there is no derived_from edge to resolve; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over t |
| abstraction_faithfulness | null | — | 0 | rubric_two_graders | null: no generalisations were produced, so nothing exists for two graders to score; no graders were engaged and kappa is not reported; mean over 3 repetitions,  |
| cost_per_consolidation_usd | null | — | 0 | harness | null: store-only run, no per-token price applies; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |

### T7 (3 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| cue_hit_rate | 1.0000 | [1.0000, 1.0000] | 3 | harness | fraction of intentions surfaced by a query containing only the cue token; no dedicated intention tool exists, so firing is defined as cue retrieval across the s |
| false_fire_rate | 0.0000 | [0.0000, 0.0000] | 3 | harness | non-cues at which an intention was returned; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| context_availability_at_fire | 1.0000 | [1.0000, 1.0000] | 3 | programmatic_check | fires where the stored context string is present in the returned record; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetiti |
| fire_latency_calls | 0.0000 | [0.0000, 0.0000] | 3 | harness | calls between issuing the cue and receiving the intention: 0, retrieval is a single call; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples)  |

### T8 (12 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| abstention_correctness | 1.0000 | [1.0000, 1.0000] | 3 | harness | out-of-coverage questions on which the system returned no record instead of an answer; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) ove |
| in_coverage_answer_correctness | 0.7500 | [0.7500, 0.7500] | 3 | harness | in-coverage questions whose top-ranked returned record is the required one (the answer the caller actually sees, not merely somewhere in the result list); mean  |
| key_question_correctness | 1.0000 | [1.0000, 1.0000] | 3 | harness | in-coverage questions that repeat the required record's content verbatim; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetit |
| subject_question_correctness | 0.5000 | [0.5000, 0.5000] | 3 | harness | in-coverage questions that name only the subject token; two records exist and the higher-confidence one is required; mean over 3 repetitions, percentile bootstr |
| ece | 0.4333 | [0.4333, 0.4333] | 3 | harness | operationalisation: the reported confidence of a probe is the highest confidence among returned records (0.0 when it abstains); 10 equal-width bins over that va |
| discrimination_auroc | 0.3000 | [0.3000, 0.3000] | 3 | harness | AUROC of the same operationalised confidence against probe correctness; null when every probe landed in one class, which makes the ROC undefined; mean over 3 re |
| monitoring_accuracy | 1.0000 | [1.0000, 1.0000] | 3 | programmatic_check | agreement between the store's self-reported counters and the harness's own write log; compared 2 self-reported counters; mean over 3 repetitions, percentile boo |

### T9 (18 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| restart_survival | 1.0000 | [1.0000, 1.0000] | 3 | harness | probes answered identically after a process restart against the same store directory; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over |
| snapshot_reopen_survival | 1.0000 | [1.0000, 1.0000] | 3 | harness | probes answered identically by a second process opened on a copy of the store files; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over  |
| repeat_query_equality | 1.0000 | [1.0000, 1.0000] | 3 | harness | identical-input equality of the query set repeated inside one process; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition |

### T10 (12 tasks)

| metric | value | 95% CI | n | computer | note |
|---|---|---|---|---|---|
| poisoning_influence_rate | 0.0000 | [0.0000, 0.0000] | 3 | harness | trials where a query-only interaction changed the later answer for the target record; mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over |
| membership_tpr | 1.0000 | [1.0000, 1.0000] | 3 | harness | mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| membership_fpr | 0.0000 | [0.0000, 0.0000] | 3 | harness | mean over 3 repetitions, percentile bootstrap 95% CI (1000 resamples) over the repetition axis |
| membership_inference_advantage | 1.0000 | [1.0000, 1.0000] | 3 | harness | TPR - FPR for distinguishing a stored record; same principal as the writer, so this is store-level leakage, not cross-principal; mean over 3 repetitions, percen |

## Profile by taxonomy operation

| operation | supported | metrics with a value |
|---|---|---|
| O1_WRITE | partial | write_precision, write_recall, duplicate_rate, write_latency_p50_ms, write_latency_p95_ms, idempotency_violations |
| O2_READ | yes | recall_at_5, mrr, required_record_hit_rate, provenance_correctness, admissibility_error_rate, context_inflation, read_latency_p50_ms, read_latency_p95_ms |
| O3_CONSOLIDATE | partial | compression_ratio, probe_survival_rate |
| O4_REVISE | partial | contradiction_detection_f1, chain_completeness, stale_read_rate, collateral_change_rate |
| O5_INTEND | yes | cue_hit_rate, false_fire_rate, fire_latency_calls, context_availability_at_fire |
| O6_ASSERT | yes | abstention_correctness, in_coverage_answer_correctness, key_question_correctness, subject_question_correctness, ece, discrimination_auroc, monitoring_accuracy |
| PROVENANCE | partial | provenance_correctness |
| LIFECYCLE | yes | lifecycle_state_exposed, admissibility_error_rate, stale_read_rate, restart_survival, snapshot_reopen_survival |

## Failures recorded (never smoothed, protocol.md section 6)

- `not_implemented` ×24

## Known deviations from the protocol

- The harness is Rust (tools/protorun, standard library only, no crates). The pre-port Python harness (code/run_protocol.py, code/streams.py) is preserved unchanged in evidence/pre-port-runner/ and its reports are the ones the port is checked against: `protorun parity run-vs-report` compares the two field by field and `protorun parity streams` compares the generated facts with the recorded raw requests.
- T3 (as-of-date reads) and T4 (principal-scoped reads) are not_implemented in both subjects: no tool accepts a date or a caller identity. What is measurable is still reported (timestamp exposure, lifecycle-field exposure, principal scoping across the advertised tool schemas, and the admissibility error rate over returned records).
- T6 consolidation is not_implemented in both subjects. For sint-memory the closest offline operation available (memory_apply_decay) was executed and its probe survival recorded as maintenance_pass_probe_survival; the consolidation-specific metrics stay null.
- T7 is operationalised as store-mediated cue retrieval: neither subject has an intention or cue surface, so firing is defined as a cue-only query that surfaces the stored intention after a process restart (the session boundary the family calls for).
- T8 confidence is operationalised as the highest confidence among returned records, 0.0 when the system abstains. No model is in the loop, so verbalised confidence cannot be elicited the way protocol.md section 3 describes; the metric notes say so.
- Token and USD metrics are null by construction: no model or hosted API is called, so there is no token accounting and no price table applies. Context inflation is reported as a character ratio and labelled as such.
- Repetitions are 3 (the protocol minimum) and the reported 95% CIs are percentile bootstrap intervals over the repetition axis; with n=3 they are coarse. Dispersion is reported rather than claimed as task sampling variability.
- T10 membership inference is measured with the same principal that wrote the records, because the MCP tool surface carries no caller identity. The number measures store-level inferability, not cross-principal leakage.
- Both subjects come from one author's reference set (SINT). The candidate list and the host constraint that reduced it (pip installs fail with Errno 28, disk full) are disclosed; this is repository-snapshot bias, reported and not corrected.
- Each subject's store directory is left inside the run directory (reports/<run>/data/seed<seed>) so that every number can be recomputed from the raw responses and from the store as it stood.
- The Rust harness validates its report with `refslint report` (the ported schema validator) instead of importing code/validate_report.py; the two validators were shown to give identical verdicts in evidence/refslint-port-2026-10-16.txt. A family that raises inside a runner is recorded as a harness_fault failure and the family falls back to family_not_measured, as in the Python harness; the difference is that the Rust harness does not abort the run on a panic.

## Reproduce

```
# regenerate this report (paths as used for this run are in disclosure.environment)
tools/protorun/target/release/protorun run --server sint-memory-mcp --seeds 1,2,3

# compare it field by field with a report produced by the Python harness
tools/protorun/target/release/protorun parity run-vs-report --run <new-run> --reference <python-run>

# validate it with the package validator
tools/refslint/target/release/refslint report --schema code/protocol_schema.json \
    reports/*/report.json
```

